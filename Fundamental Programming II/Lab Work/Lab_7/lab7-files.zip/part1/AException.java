public class AException extends Exception
{

}

