public class BException extends Exception
{

}

